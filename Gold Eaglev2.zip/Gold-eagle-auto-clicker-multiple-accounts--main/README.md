# Gold-eagle-auto-clicker-multiple-accounts-
Auto clicker bot script Gold eagle 

https://t.me/gold_eagle_coin_bot/main?startapp=r_SH4F6bH1sK

how it works video 📷:
https://youtu.be/g2JEJnhjruE?si=6r0aRc9hy2kESOp5
